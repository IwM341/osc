/*
 * Copyright (c) 2010 ���ǵ���
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

/*
 * ����Ȩ����(C) 2010 ���ǵ���
 *
 * ������Ϊ���������������������������������������GNUͨ�ù�����Ȩ����涨��
 * �ͱ�������Ϊ�����룯���޸ģ����������ݵ��Ǳ���Ȩ�ĵڶ����������ѡ��ģ�
 * ��һ�պ��еİ汾��

 * �������ǻ���ʹ��Ŀ�Ķ����Է�����Ȼ�������κε������Σ����޶������Ի��ض�
 * Ŀ����������Ϊ��Ĭʾ�Ե��������������GNUͨ�ù�����Ȩ��

 * ��Ӧ���յ������ڱ������GNUͨ�ù�����Ȩ�ĸ��������û�У���д������������
 * ����᣺59 Temple Place - Suite 330, Boston, Ma 02111-1307, USA��

 * Email yixingdianzi@126.com
 * Email/MSN yixingdianzi@hotmail.com
 * QQ 648887464
 */

/******************** (C) COPYRIGHT 2009 STMicroelectronics ********************
* File Name          : stm32f10x_it.c
* Author             : MCD Application Team
* Version            : V3.1.0
* Date               : 10/30/2009
* Description        : Main Interrupt Service Routines.
*                      This file provides template for all exceptions handler
*                      and peripherals interrupt service routine.
********************************************************************************
* THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
* AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
* INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
* CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
* INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
*******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x_it.h"
#include "usb_lib.h"
#include "usb_istr.h"
#include "usb_desc.h"						
#include "usb_pwr.h"
#include "qdmx_adc.h"
//#include "stm32_dsp.h"

extern __IO uint32_t count_in;
//uint32_t count;

uint8_t ADCConvertedValue[4];
extern uint8_t UsbInBuffer[16384];
extern uint32_t UsbInBufferCount;
extern uint8_t filter;

int out_put[N];/*filter output vector*/
short in_put[M+N-1];/*filter input vector*/
short h[M]={ 9958, 22810, 22810, 9958};/*filter coefficients vector ����ϵ����65536*/
/*��Ϊ����������˲�ϵ������16λ�������ʱ32λ�������ｫ��Ƶ��˲���ϵ����65536�������Ϊ16λ��
������鲻��������
*/
COEFS fir_coefs;/*coefficients structure*/

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/******************************************************************************/
/*            Cortex-M3 Processor Exceptions Handlers                         */
/******************************************************************************/

/*******************************************************************************
* Function Name  : NMI_Handler
* Description    : This function handles NMI exception.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void NMI_Handler(void)
{
}

/*******************************************************************************
* Function Name  : HardFault_Handler
* Description    : This function handles Hard Fault exception.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void HardFault_Handler(void)
{
  /* Go to infinite loop when Hard Fault exception occurs */
  while (1)
  {
  }
}

/*******************************************************************************
* Function Name  : MemManage_Handler
* Description    : This function handles Memory Manage exception.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void MemManage_Handler(void)
{
  /* Go to infinite loop when Memory Manage exception occurs */
  while (1)
  {
  }
}

/*******************************************************************************
* Function Name  : BusFault_Handler
* Description    : This function handles Bus Fault exception.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void BusFault_Handler(void)
{
  /* Go to infinite loop when Bus Fault exception occurs */
  while (1)
  {
  }
}

/*******************************************************************************
* Function Name  : UsageFault_Handler
* Description    : This function handles Usage Fault exception.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void UsageFault_Handler(void)
{
  /* Go to infinite loop when Usage Fault exception occurs */
  while (1)
  {
  }
}

/*******************************************************************************
* Function Name  : SVC_Handler
* Description    : This function handles SVCall exception.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void SVC_Handler(void)
{
}

/*******************************************************************************
* Function Name  : DebugMon_Handler
* Description    : This function handles Debug Monitor exception.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void DebugMon_Handler(void)
{
}

/*******************************************************************************
* Function Name  : PendSV_Handler
* Description    : This function handles PendSVC exception.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void PendSV_Handler(void)
{
}

/*******************************************************************************
* Function Name  : SysTick_Handler
* Description    : This function handles SysTick Handler.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void SysTick_Handler(void)
{
}

/******************************************************************************/
/*            STM32F10x Peripherals Interrupt Handlers                        */
/******************************************************************************/

/*******************************************************************************
* Function Name  : DMA1_Channel1_IRQHandler
* Description    : This function handles DMA1 Channel 1 interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void DMA1_Channel1_IRQHandler(void)
{  
    DMA_ClearFlag(DMA1_FLAG_TC1);

	if(filter==1)
	{
	    in_put[3]=ADCConvertedValue[0]-1;  //-1 -3 +2 +5 Ϊ�ˣ��鿴Ч������������
		in_put[4]=ADCConvertedValue[1]-3;
		in_put[5]=ADCConvertedValue[2]+2;
		in_put[6]=ADCConvertedValue[3]+5;

	    //����fir�˲�����
		fir_16by16_stm32(out_put,in_put,&fir_coefs,N);/*performs the FIR filtering*/
	
		//����������3��������
		in_put[0]=in_put[4];
		in_put[1]=in_put[5];
		in_put[2]=in_put[6];

		//���˲������ݷ���USB������
		UsbInBuffer[UsbInBufferCount++]=(out_put[0])>>16;	 //65536
		UsbInBuffer[UsbInBufferCount++]=(out_put[1])>>16;
		UsbInBuffer[UsbInBufferCount++]=(out_put[2])>>16;
		UsbInBuffer[UsbInBufferCount++]=(out_put[3])>>16;
	}
	else
	{
	    UsbInBuffer[UsbInBufferCount++]=ADCConvertedValue[0]-1;	 //-1 -3 +2 +5 Ϊ�ˣ��鿴Ч������������
		UsbInBuffer[UsbInBufferCount++]=ADCConvertedValue[1]-3;
		UsbInBuffer[UsbInBufferCount++]=ADCConvertedValue[2]+2;
		UsbInBuffer[UsbInBufferCount++]=ADCConvertedValue[3]+5; 
	}

	if(UsbInBufferCount>=16384)
	{
		ADC_Cmd(ADC1, DISABLE);
		SetEPDblBuffCount(ENDP1 , EP_DBUF_IN , 64);
		if((bDeviceState == CONFIGURED))
	    {
		  	if (GetENDPOINT(ENDP1) & EP_DTOG_RX)
		  	{
			  FreeUserBuffer(ENDP1, EP_DBUF_IN); 
		      UserToPMABufferCopy(UsbInBuffer, ENDP1_TX1ADDR, 64);
		      SetEPDblBuf1Count(ENDP1,EP_DBUF_IN,64);
		  	}
		  	else
		  	{
		   	  FreeUserBuffer(ENDP1, EP_DBUF_IN); 
		      UserToPMABufferCopy(UsbInBuffer, ENDP1_TX0ADDR, 64);
		      SetEPDblBuf0Count(ENDP1,EP_DBUF_IN,64);
		  	}
			count_in=1;
		}  
	}
}


#ifndef STM32F10X_CL
/*******************************************************************************
* Function Name  : USB_HP_CAN1_TX_IRQHandler
* Description    : This function handles USB High Priority or CAN TX interrupts requests
*                  requests.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void USB_HP_CAN1_TX_IRQHandler(void)
{
  if(bDeviceState==CONFIGURED)
      CTR_HP();
}

/*******************************************************************************
* Function Name  : USB_LP_CAN1_RX0_IRQHandler
* Description    : This function handles USB Low Priority or CAN RX0 interrupts
*                  requests.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void USB_LP_CAN1_RX0_IRQHandler(void)
{
  USB_Istr();
}
#endif /* STM32F10X_CL */

/*******************************************************************************
* Function Name  : USART1_IRQHandler
* Description    : This function handles USART1 global interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void USART1_IRQHandler(void)
{
}

/*******************************************************************************
* Function Name  : USART2_IRQHandler
* Description    : This function handles USART2 global interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void USART2_IRQHandler(void)
{
}

#ifdef STM32F10X_CL
/*******************************************************************************
* Function Name  : OTG_FS_IRQHandler
* Description    : This function handles USB-On-The-Go FS global interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void OTG_FS_IRQHandler(void)
{
  STM32_PCD_OTG_ISR_Handler(); 
}
#endif /* STM32F10X_CL */

/******************************************************************************/
/*                 STM32F10x Peripherals Interrupt Handlers                   */
/*  Add here the Interrupt Handler for the used peripheral(s) (PPP), for the  */
/*  available peripheral interrupt handler's name please refer to the startup */
/*  file (startup_stm32f10x_xx.s).                                            */
/******************************************************************************/

/*******************************************************************************
* Function Name  : PPP_IRQHandler
* Description    : This function handles PPP interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
/*void PPP_IRQHandler(void)
{
}*/

/******************* (C) COPYRIGHT 2009 STMicroelectronics *****END OF FILE****/

