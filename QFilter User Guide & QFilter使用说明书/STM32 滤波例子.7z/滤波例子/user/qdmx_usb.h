
#ifndef __QDMX_USB_H
#define __QDMX_USB_H

#include "stm32f10x.h"
#include "usb_type.h"
#include "usb_pwr.h"
#include "usb_lib.h"
#include "usb_conf.h"


#define USB_DISCONNECT                      GPIOD  
#define USB_DISCONNECT_PIN                  GPIO_Pin_9
#define RCC_APB2Periph_GPIO_DISCONNECT      RCC_APB2Periph_GPIOD

void USB_GPIO_Config(void);
void Set_USBClock(void);
void USB_Interrupts_Config(void);

void USB_Cable_Config (FunctionalState NewState);

void Enter_LowPowerMode(void);
void Leave_LowPowerMode(void);

void Get_SerialNum(void);

#endif /* __QDMX_USB_H */

