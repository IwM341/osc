/*
 * Copyright (c) 2010 ���ǵ���
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

/*
 * ����Ȩ����(C) 2010 ���ǵ���
 *
 * ������Ϊ���������������������������������������GNUͨ�ù�����Ȩ����涨��
 * �ͱ�������Ϊ�����룯���޸ģ����������ݵ��Ǳ���Ȩ�ĵڶ����������ѡ��ģ�
 * ��һ�պ��еİ汾��

 * �������ǻ���ʹ��Ŀ�Ķ����Է�����Ȼ�������κε������Σ����޶������Ի��ض�
 * Ŀ����������Ϊ��Ĭʾ�Ե��������������GNUͨ�ù�����Ȩ��

 * ��Ӧ���յ������ڱ������GNUͨ�ù�����Ȩ�ĸ��������û�У���д������������
 * ����᣺59 Temple Place - Suite 330, Boston, Ma 02111-1307, USA��

 * Email yixingdianzi@126.com
 * Email/MSN yixingdianzi@hotmail.com
 * QQ 648887464
 */

/******************** (C) COPYRIGHT 2009 STMicroelectronics ********************
* File Name          : main.c
* Author             : MCD Application Team
* Version            : V3.1.0
* Date               : 10/30/2009
* Description        : Virtual Com Port Demo main file
********************************************************************************
* THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
* AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
* INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
* CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
* INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
*******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
#include "stm32f10x_gpio.h"
#include "usb_lib.h"
#include "usb_desc.h"
#include "usb_pwr.h"
#include "qdmx_usb.h"
#include "qdmx_adc.h"
#include "stm32f10x_it.h"

#define SEND 32

//int a[N];/*filter output vector*/
extern short in_put[M+N-1];/*filter input vector*/
extern short h[M];/*filter coefficients vector ����ϵ����65535*/
extern COEFS fir_coefs;/*coefficients structure*/

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Extern variables ----------------------------------------------------------*/
extern __IO uint32_t count_in;

/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
void Set_System(void);
void Callback(uint8_t *p);
void Delay(__IO uint32_t nCount);
void GPIO_configure(void);					
/*******************************************************************************
* Function Name  : main.
* Description    : Main routine.				
* Input          : None.
* Output         : None.
* Return         : None.
*******************************************************************************/
int main(void)
{  
    char i=0;
	vu8 s;
	/*����ϵͳʱ��*/
	Set_System();
	
	/*��ʼ��USBģ��*/  
	Set_USBClock();
	USB_Interrupts_Config();
	USB_Init();
	/*��ʼ��ADģ��*/
	m_adc_clk_config();
  	m_adc_gpio_config();
  	m_adc_Interrupts_Config();
  	m_adc_init();

	/*��ʼ��GPIO������Ϊ�Ŵ��������*/
	GPIO_configure();
					   
  	count_in=0;

	//firϵ����ʼ��
  	fir_coefs.nh = M; /*Number of Coefficients for FIR*/
  	fir_coefs.h = h; /*Pointer on FIR coefficient vector*/
  	//��������������0����ʼ��
  	for(i=0;i<M+N-1;i++)
    	in_put[i]=0;

  	while (1)
  	{		 
  	}
}

void GPIO_configure(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA , ENABLE);
  	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB , ENABLE);
	
	RCC_AHBPeriphClockCmd(RCC_APB2Periph_GPIOA , ENABLE);
	RCC_AHBPeriphClockCmd(RCC_APB2Periph_GPIOB , ENABLE);		
 
  	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14;
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  	GPIO_Init(GPIOB, &GPIO_InitStructure);

	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2;
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  	GPIO_Init(GPIOA, &GPIO_InitStructure);
}

void Delay(__IO uint32_t nCount)
{
  for(; nCount != 0; nCount--);
}


void Callback(uint8_t *p)
{
	if (GetENDPOINT(ENDP1) & EP_DTOG_RX)
	{
	   	FreeUserBuffer(ENDP1, EP_DBUF_IN);
	   	UserToPMABufferCopy((uint8_t*) p, ENDP1_TX1ADDR, SEND);
	   	SetEPDblBuf1Count(ENDP1,EP_DBUF_IN,SEND);
	}
	else
	{
	   	FreeUserBuffer(ENDP1, EP_DBUF_IN);
	   	UserToPMABufferCopy((uint8_t*) p, ENDP1_TX0ADDR, SEND);
	   	SetEPDblBuf0Count(ENDP1,EP_DBUF_IN,SEND);
	}
}

#ifdef USE_FULL_ASSERT
/*******************************************************************************
* Function Name  : assert_failed
* Description    : Reports the name of the source file and the source line number
*                  where the assert_param error has occurred.
* Input          : - file: pointer to the source file name
*                  - line: assert_param error line source number
* Output         : None
* Return         : None
*******************************************************************************/
void assert_failed(uint8_t* file, uint32_t line)
{
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {}
}
#endif

/*******************************************************************************
* Function Name  : Set_System
* Description    : Configures Main system clocks & power
* Input          : None.
* Return         : None.
*******************************************************************************/
void Set_System(void)
{
  ErrorStatus HSEStartUpStatus;
  /* SYSCLK, HCLK, PCLK2 and PCLK1 configuration -----------------------------*/   
  /* RCC system reset(for debug purpose) */
  RCC_DeInit();

  /* Enable HSE */
  RCC_HSEConfig(RCC_HSE_ON);

  /* Wait till HSE is ready */
  HSEStartUpStatus = RCC_WaitForHSEStartUp();

  if (HSEStartUpStatus == SUCCESS)
  {
    /* Enable Prefetch Buffer */
    FLASH_PrefetchBufferCmd(FLASH_PrefetchBuffer_Enable);

    /* Flash 2 wait state */
    FLASH_SetLatency(FLASH_Latency_2);
 
    /* HCLK = SYSCLK */
    RCC_HCLKConfig(RCC_SYSCLK_Div1); 
  
    /* PCLK2 = HCLK */
    RCC_PCLK2Config(RCC_HCLK_Div1); 

    /* PCLK1 = HCLK/2 */
    RCC_PCLK1Config(RCC_HCLK_Div2);

#ifdef STM32F10X_CL
    /* Configure PLLs *********************************************************/
    /* PLL2 configuration: PLL2CLK = (HSE / 5) * 8 = 40 MHz */
    RCC_PREDIV2Config(RCC_PREDIV2_Div5);
    RCC_PLL2Config(RCC_PLL2Mul_8);

    /* Enable PLL2 */
    RCC_PLL2Cmd(ENABLE);

    /* Wait till PLL2 is ready */
    while (RCC_GetFlagStatus(RCC_FLAG_PLL2RDY) == RESET)
    {}

    /* PLL configuration: PLLCLK = (PLL2 / 5) * 9 = 72 MHz */ 
    RCC_PREDIV1Config(RCC_PREDIV1_Source_PLL2, RCC_PREDIV1_Div5);
    RCC_PLLConfig(RCC_PLLSource_PREDIV1, RCC_PLLMul_9);
#else
    /* PLLCLK = 8MHz * 9 = 72 MHz */
    RCC_PLLConfig(RCC_PLLSource_HSE_Div1, RCC_PLLMul_9);
#endif

    /* Enable PLL */ 
    RCC_PLLCmd(ENABLE);

    /* Wait till PLL is ready */
    while (RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET)
    {
    }

    /* Select PLL as system clock source */
    RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);

    /* Wait till PLL is used as system clock source */
    while(RCC_GetSYSCLKSource() != 0x08)
    {
    }
  }
  else
  { /* If HSE fails to start-up, the application will have wrong clock configuration.
       User can add here some code to deal with this error */    

    /* Go to infinite loop */
    while (1)
    {
    }
  }
}
/******************* (C) COPYRIGHT 2009 STMicroelectronics *****END OF FILE****/
